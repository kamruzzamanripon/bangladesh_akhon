<?php
 
add_action('init', 'industry_toolkit_kc_addons', 99 );
 
function industry_toolkit_kc_addons() {
 
	if (function_exists('kc_add_map')) 
	{ 
	    kc_add_map(
	        array(

	            'industry_section_title' => array(
	                'name' => 'Section Title',
	                'description' => __('Use this addon for display section title', 'KingComposer'),
	                'icon' => 'fa fa-tasks',
	                'category' => 'Industry',
	                'params' => array(
	                    'General' => array(
	                    	array(
	                        'name' => 'sub_title',
	                        'label' => 'sub_title',
	                        'type' => 'text',
	                        'description' => 'Type section sub-title'
		                    ),
		                    array(
		                        'name' => 'title',
		                        'label' => 'Title',
		                        'type' => 'text',
		                        'description' => 'Type section sub-title'
		                    ),
		                    array(
		                        'name' => 'description',
		                        'label' => 'Description',
		                        'type' => 'textarea',
		                        'description' => 'Type Details'
		                    ),	
	                    ),

	                    'css' => array(
	                    	array(
	                    		'name' => 'custom-css',	
	                    		'type' => 'css',
	                    		'options' => array(
									array(
										'screens' => "any",
										'Typography' => array(
											array('property' => 'color', 'label' => 'Color'),
											array('property' => 'font-size', 'label' => 'Font Size'),
										),

										//Background group
										'Background' => array(
											array('property' => 'background'),
										),

										//Box group
										'Box' => array(
											array('property' => 'margin', 'label' => 'Margin'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'width', 'label' => 'Width'),
											array('property' => 'height', 'label' => 'Height'),
											array('property' => 'border-radius', 'label' => 'Border Radius'),
											array('property' => 'float', 'label' => 'Float'),
											array('property' => 'display', 'label' => 'Display'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'opacity', 'label' => 'Opacity'),
										),
									),
									array(
										"screens" => "999,768,667,479",
										'Typography' => array(
											array('property' => 'font-size', 'label' => 'Font Size'),
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'line-height', 'label' => 'Line Height'),
											array('property' => 'word-break', 'label' => 'Word Break'),	
										),

										//Background group
										'Background' => array(
											array('property' => 'background'),
										),

										//Box group
										'Box' => array(
											array('property' => 'width', 'label' => 'Width'),
											array('property' => 'margin', 'label' => 'Margin'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'height', 'label' => 'Height'),
											array('property' => 'border-radius', 'label' => 'Border Radius'),
											array('property' => 'float', 'label' => 'Float'),
											array('property' => 'display', 'label' => 'Display'),
										),
									)
								),	
	                    	),
	                    )
	                    
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map

	   

	    kc_add_map(
	        array(

	            'industry_service_box' => array(
	                'name' => 'Service Box',
	                'description' => __('Use this addon for display Service Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'icon_type',
	                        'label' => 'icon_type',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'1' => 'Select Icon',
									'2' => 'Upload Icon',
								),
	                        'description' => 'Select Serivce Box item type',
	                        'value' => 1,
	                    ),
	                    array(
	                        'name' => 'fa_icon',
	                        'label' => 'Icon',
	                        'type' => 'icon_picker',
	                        'description' => 'Choose Service Box icon',
	                        'relation' => array(
	                        	'parent' => 'icon_type',	
	                        	'show_when' => '1',	
	                        	)
	                    ),
	                    array(
	                        'name' => 'img_icon',
	                        'label' => 'Upload Icon',
	                        'type' => 'attach_image',
	                        'description' => 'Upload Service Box icon',
	                        'relation' => array(
	                        	'parent' => 'icon_type',	
	                        	'hide_when' => '1',	
	                        	)
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Title',
	                        'type' => 'text',
	                        'description' => 'Type section sub-title'
	                    ),
	                    array(
	                        'name' => 'description',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => 'Type Details'
	                    ),
	                    array(
                        'name' => 'color',
                        'label' => 'Select Color',
                        'type' => 'color_picker',
                        'admin_label' => true,
                    ),
	                    
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map

	    kc_add_map(
	        array(

	            'industry_service_box2' => array(
	                'name' => 'Service Box 2',
	                'description' => __('Use this addon for display Service Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
						array(
	                        'name' => 'img',
	                        'label' => 'Upload Icon',
	                        'type' => 'attach_image',
	                        'description' => 'Upload Service Image Thumbnail',
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Title',
	                        'type' => 'text',
	                        'description' => 'Type section sub-title'
	                    ),
	                    array(
	                        'name' => 'description',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => 'Type Details'
	                    ),
	                    array(
                        'name' => 'link',
                        'label' => 'Link',
                        'type' => 'link',
                        'description' => 'Select section link',
                    ),
	                    
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map


	    kc_add_map(
	        array(

	            'industry_service_box3' => array(
	                'name' => 'Service Box3',
	                'description' => __('Use this addon for display Service Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'icon_type',
	                        'label' => 'icon_type',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'1' => 'Select Icon',
									'2' => 'Upload Icon image',
								),
	                        'description' => 'Select Serivce Box item type',
	                        'value' => 1,
	                    ),
	                    array(
	                        'name' => 'fa_icon',
	                        'label' => 'Icon',
	                        'type' => 'icon_picker',
	                        'description' => 'Choose Service Box icon',
	                        'relation' => array(
	                        	'parent' => 'icon_type',	
	                        	'show_when' => '1',	
	                        	)
	                    ),
	                    array(
	                        'name' => 'img_icon',
	                        'label' => 'Upload Icon',
	                        'type' => 'attach_image',
	                        'description' => 'Upload Service Box icon',
	                        'relation' => array(
	                        	'parent' => 'icon_type',	
	                        	'hide_when' => '1',	
	                        	)
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Title',
	                        'type' => 'text',
	                        'description' => 'Type section sub-title'
	                    ),
	                    array(
	                        'name' => 'description',
	                        'label' => 'Description',
	                        'type' => 'textarea',
	                        'description' => 'Type Details'
	                    ),
	                    array(
                        'name' => 'link',
                        'label' => 'See More',
                        'type' => 'link',
                        'description' => 'Select See more link',
                    ),
	                    
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map


	    kc_add_map(
	        array(

	            'industry_slides' => array(
	                'name' => 'Industry Slides',
	                'description' => __('Use this addon for display Industry Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
	                	array(
	                        'name' => 'category',
	                        'label' => 'Category',
	                        'type' => 'select',
	                        'options' => industry_theme_slide_cat_list(),
	                    ),
	                    array(
	                        'name' => 'count',
	                        'label' => 'slides count',
	                        'type' => 'text',
	                        'description' => '',
	                        'value' => 3,
	                    ),
	                     array(
	                        'name' => 'loop',
	                        'label' => 'Loop',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                     array(
	                        'name' => 'dots',
	                        'label' => 'Dots',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                     array(
	                        'name' => 'nav',
	                        'label' => 'Nav',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                      array(
	                        'name' => 'autoplay',
	                        'label' => 'Autoplay',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                     array(
	                        'name' => 'autoplayTimeout',
	                        'label' => 'slides Time',
	                        'type' => 'text',
	                        'description' => 'Type slide time in mili seconds',
	                        'value' => 5000,
	                        'relation' => array(
	                        	'parent' => 'autoplay',	
	                        	'show_when' => 'true',	
	                        	),
	                    ), 

	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map

	    kc_add_map(
	        array(

	            'industry_counter_box' => array(
	                'name' => 'Counter Box',
	                'description' => __('Use this addon for display counter Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'icon_type',
	                        'label' => 'icon_type',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'1' => 'Select Icon',
									'2' => 'Upload Icon',
								),
	                        'description' => 'Select Serivce Box item type',
	                        'value' => 1,
	                    ),
	                    array(
	                        'name' => 'fa_icon',
	                        'label' => 'Icon',
	                        'type' => 'icon_picker',
	                        'description' => 'Choose counter Box icon',
	                        'relation' => array(
	                        	'parent' => 'icon_type',	
	                        	'show_when' => '1',	
	                        	)
	                    ),
	                    array(
	                        'name' => 'img_icon',
	                        'label' => 'Upload Icon',
	                        'type' => 'attach_image',
	                        'description' => 'Upload counter Box icon',
	                        'relation' => array(
	                        	'parent' => 'icon_type',	
	                        	'hide_when' => '1',	
	                        	)
	                    ),
	                    array(
	                        'name' => 'sub_title',
	                        'label' => 'Sub Title',
	                        'type' => 'text',
	                        'description' => 'Type section sub-title'
	                    ),
	                    array(
	                        'name' => 'count_number',
	                        'label' => 'Count Number',
	                        'type' => 'text',
	                        'description' => 'Type Count Number'
	                    ),
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map


	    /*Case Study Addone*/
	     kc_add_map(
	        array(

	            'industry_case_study' => array(
	                'name' => 'Case Study',
	                'description' => __('Use this addon for Case Study Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
						array(
	                        'name' => 'img',
	                        'label' => 'Case Study Thumbnail',
	                        'type' => 'attach_image',
	                        'description' => 'Upload Case Study Thumbnail',
	                    ),
	                    array(
	                        'name' => 'title',
	                        'label' => 'Case Study Title',
	                        'type' => 'text',
	                        'description' => 'Type Case Study title'
	                    ),
	                    array(
	                        'name' => 'description',
	                        'label' => 'Case Study Description',
	                        'type' => 'textarea',
	                        'description' => 'Case Study Type Details'
	                    ),
	                    array(
                        'name' => 'link',
                        'label' => 'Case Study Link',
                        'type' => 'link',
                        'description' => 'Select Case Study link',
                    ),
	                    
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map




	     /*Slide 2 Addone*/
	     kc_add_map(
	        array(

	            'industry_slides2' => array(
	                'name' => 'industry-slide2',
	                'description' => __('Use this addon for display Industry Box', 'KingComposer'),
	                'icon' => 'fa fa-github-alt',
	                'category' => 'Industry',
	                'params' => array(
	                    array(
	                        'name' => 'count',
	                        'label' => 'slides count',
	                        'type' => 'text',
	                        'description' => '',
	                        'value' => 3,
	                    ),
	                     array(
	                        'name' => 'loop',
	                        'label' => 'Loop',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                     array(
	                        'name' => 'dots',
	                        'label' => 'Dots',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                     array(
	                        'name' => 'nav',
	                        'label' => 'Nav',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                      array(
	                        'name' => 'autoplay',
	                        'label' => 'Autoplay',
	                        'type' => 'select',
	                        'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'true' => 'Yes',
									'false' => 'No',
								),
	                        'value' => true,
	                    ),
	                     array(
	                        'name' => 'autoplayTimeout',
	                        'label' => 'slides Time',
	                        'type' => 'text',
	                        'description' => 'Type slide time in mili seconds',
	                        'value' => 5000,
	                        'relation' => array(
	                        	'parent' => 'autoplay',	
	                        	'show_when' => 'true',	
	                        	),
	                    ),
	                    array(
	                        'name' => 'button_text',
	                        'label' => 'Button Text',
	                        'type' => 'text',
	                        'value' => 'Build your product',
	                    ),
	                     array(
	                        'name' => 'button_link',
	                        'label' => 'Button Link',
	                        'type' => 'link',
	                        'value' => 'Build your product',
	                    ),  

	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map





	} // End if

}  
 
