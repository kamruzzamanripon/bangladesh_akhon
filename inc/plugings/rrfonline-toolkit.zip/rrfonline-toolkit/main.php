<?php

/*
Plugin Name: RRF Online Toolkit
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This pluging use for Learning and Test
Author: Syed Kamruzzaman
Version: 1.0
Author URI: http://www.bangladeshakhon24.com/
*/


function industry_toolkit_include_files(){
	wp_enqueue_style('owl-carousel', plugins_url('/assets/css/owl.carousel.min.css', __FILE__ ) );
	wp_enqueue_style('industry-toolkit', plugins_url('/assets/css/industry-toolkit.css', __FILE__ ) );

	wp_enqueue_script('wl-carousel', plugins_url('/assets/js/owl.carousel.min.js', __FILE__ ), array('jquery'), '2.1.1', true );
}
add_action('wp_enqueue_scripts','industry_toolkit_include_files' );

add_filter('widget_text','do_shortcode');



function rrf_shortcode_query($atts, $content = null){

	extract(shortcode_atts( array(
			'count' => '',
		), $atts));

	$array = array (
		'post_type' => 'page',

	);

	$get_post = new WP_Query($array);


	$list_markup = '<div class="col-md-12">';
	$list_markup .= '<h1>Top Recent Page Title</h1>';
	$list_markup .= '<ul>';
		while($get_post->have_posts()) : $get_post->the_post();
		$post_id = get_the_ID();
		$list_markup .= '<li>'.get_the_title($post_id).'</li>';
		endwhile;
	$list_markup .= '</ul>';
	wp_reset_query();
	$list_markup .= '</div>';

	return $list_markup;

}
add_shortcode('risort_code', 'rrf_shortcode_query' );



function industry_theme_custom_post() {
    register_post_type( 'industry-slide',
        array(
            'labels' => array(
                'name' => __( 'Slides' ),
                'singular_name' => __( 'Slide' )
            ),
            'supports' => array('title', 'editor','thumbnail', 'page-attributes'),
            'public' => false,
            'show_ui' => true
        )
    );
}
add_action( 'init', 'industry_theme_custom_post' );



/*Slider 2 */
function industry_theme_custom_post_slide2() {
    register_post_type( 'industry-slide2',
        array(
            'labels' => array(
                'name' => __( 'Slides2' ),
                'singular_name' => __( 'Slide2' )
            ),
            'supports' => array('title', 'editor','thumbnail', 'page-attributes'),
            'public' => false,
            'show_ui' => true
        )
    );
}
add_action( 'init', 'industry_theme_custom_post_slide2' );



/*For Create Slide Taxonomy Registration*/
function industry_theme_custom_post_taxonomy() {
    register_taxonomy(
        'industry_cat',  
        'industry-slide',                  
        array(
            'hierarchical'          => true,
            'label'                 => 'Slide Category',  
            'query_var'             => true,
            'show_admin_column'     => true,
            'rewrite'               => array(
                'slug'              => 'slide-category', 
                'with_front'    => true 
                )
            )
    );
}
add_action( 'init', 'industry_theme_custom_post_taxonomy');

/*Slide Taxonomy usa a custom function. that why no use Hook*/
function industry_theme_slide_cat_list(){
	$slide_categories = get_terms( 'industry_cat' );

	$slide_category_options = array ('' => esc_html__( 'All category', 'upbuild-toolkit' ));
	if($slide_categories) {
		foreach ($slide_categories as $slide_category) {
			$slide_category_options[$slide_category->term_id] = $slide_category->name;
		}
	}

	return $slide_category_options;
}







include_once('industry-toolkit-kc-addons.php');
include_once('industry-toolkit-shortcode.php');



?>