<?php
	function isotope_filter_shortcode($atts, $content = null){

	extract(shortcode_atts( array(
			'lat' 	=> '',
			
		), $atts));


	$project_categories = get_terms( 'project_cat' );
	$dynamic_number = rand(5444999, 4499664);


	
	$isotope_filter_markup = '
	<script>
		jQuery(document).ready(function($){
			$(".project-ul li").click(function(){
				$(".project-ul li").removeClass("active");
				$(this).addClass("active");

				var selectore = $(this).attr("data-filter");
				$(".project-list-'.$dynamic_number.'").isotope({
					filter: selectore,
				});
			});
		});

		jQuery(window).load(function(){
				jQuery(".project-list-'.$dynamic_number.'").isotope();
		});
		
	</script>';
		
	/*Start Ul li List*/		
	$isotope_filter_markup .= '	
		<div class="container">
			<div class="row">
				<div class="col-md-3">
					<div class="project-left">
						<ul class="project-ul">
							<li class="active" data-filter="*" >All Color</li>';

		if(! empty( $project_categories ) && ! is_wp_error( $project_categories )){
				foreach ($project_categories as $category) {
					$isotope_filter_markup .= '<li data-filter=".'.$category->slug.'" > '.$category->name.'  </li>';
				}

			
		}					
	
	$isotope_filter_markup .= '						
						</ul>
					</div>
				</div>';

	


	/*Start Iteams Details*/			
	$isotope_filter_markup .= '			
				<div class="col-md-9">
					<div class="project-right">
						<div class="row project-list-'.$dynamic_number.'">';

	
	$project_array = new WP_Query(array('posts_per_page' => -1, 'post_type' => 'project'));	

	while($project_array->have_posts()) : $project_array->the_post();
		$post_id = get_the_ID();

	$project_category = get_the_terms(get_the_ID(), 'project_cat');
	if(! empty( $project_category ) && ! is_wp_error( $project_category )){
		$project_cat_list = array();

		foreach ($project_category as $category) {
				$project_cat_list[] = $category->slug; 
			}
			$project_assigned_cat = join( " ", $project_cat_list );	

	}else{
			$project_assigned_cat = '';	
	}	



	$isotope_filter_markup .= '					
							<div class="col-md-4 '.$project_assigned_cat.' ">
								<a href="'.get_permalink($post_id).'" class="single-work-box">
									<div class="work-box-bg" style="background-image:url('.get_the_post_thumbnail_url($post_id, 'large').')"> <i class="fa fa-link"></i> </div>
									<p>'.get_the_title($post_id).'</p>
								</a>
							</div>';
	endwhile;
	wp_reset_query();						
	

	$isotope_filter_markup .= '						
						</div>
					</div>
				</div>
			</div>
		</div>	
	';
	
	


	return $isotope_filter_markup;

}
add_shortcode('isotope_filter', 'isotope_filter_shortcode' );

?>