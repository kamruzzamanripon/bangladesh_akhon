<?php
	function industry_google_map_shortcode($atts, $content = null){

	extract(shortcode_atts( array(
			'lat' 	=> '23.73202',
			'lng' 	=> '90.4237333',
			
		), $atts));

	
	$google_map_style_markup = '
			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCnTxA05P79bwbpgfoCNVktqGFddgts_mw&callback=initMap"></script>

			
			<div style="width:100%; height:500px;" class="map"></div>
			<script>
				 jQuery(document).ready(function($) {
					var myplace = {lat: '.$lat.', lng: '.$lng.'}; 
				    $(".map")
				      .gmap3({
				        center: myplace,
				        zoom:14,
				        //scrollwheel: false,
				        mapTypeId: "shadeOfGrey", // to select it directly
				        mapTypeControlOptions: {
				          mapTypeIds: [google.maps.MapTypeId.ROADMAP, "shadeOfGrey"]
				        }
				      })
				      .marker({
				        position: myplace,
				      })
				      .infowindow({
				        content: "CustomerPlus"
				      })
				    
				      .styledmaptype(
				        "shadeOfGrey",
				        [
				          {"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},
				          {"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},
				          {"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},
				          {"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#eeeeee"},{"lightness":20}]},
				          {"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#eeeeee"},{"lightness":17},{"weight":1.2}]},
				          {"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#d2ddd3"},{"lightness":20}]},
				          {"featureType":"poi","elementType":"geometry","stylers":[{"color":"#118538"},{"lightness":21}]},
				          {"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},
				          {"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},
				          {"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},
				          {"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},
				          {"featureType":"transit","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":19}]},
				          {"featureType":"water","elementType":"geometry","stylers":[{"color":"#9fc1fe"},{"lightness":17}]}
				        ],
				        {name: "CustomerPlus"}
				      );

				  });
		  </script>

		

	';
	
	


	return $google_map_style_markup;

}
add_shortcode('google_styled_map', 'industry_google_map_shortcode' );

?>